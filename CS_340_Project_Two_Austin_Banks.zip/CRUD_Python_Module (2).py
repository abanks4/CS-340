# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
    def get_next_record_number(self):
        # Find document with the highest record number
        last_record = self.collection.find_one(
            sort = [("rec_num", -1)]
        )
        
        # If there are no records, start with number 1
        if last_record is None:
            return 1
        
        #Return next available record number
        return last_record["rec_num"] + 1
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            self.database.animals.insert_one(data)  
            # data should be dictionary 
            return True
        else: 
            raise Exception("Nothing to save, because data parameter is empty")
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        try:
            #Use find() to return a cursor with matching documents
            cursor = self.collection.find(query)
            #Convert the MongoDB cursor into a list
            return list(cursor)
        except Exception as e:
            print("Error querying documents:", e)
            return []
       
    # Update method to implement the U in CRUD.
    def update(self, query, new_data):
        try:
            #Update the document matching the query
            result = self.collection.update_many(query, {"$set": new_data})
            #Return the number of documents modifed.
            return result.modified_count
        except Exception as e:
            print ("Error updating document:", e)
            return 0
            
     #Delete method to implment the D in CRUD
    def delete(self, query):
        try:
            #Delete documents matching the query
            result = self.collection.delete_many(query)
                        
            #Return the number of documents removed
            return result.deleted_count
            
        except Exception as e:
            print("Error deleting documents:", e)
            return 0
        